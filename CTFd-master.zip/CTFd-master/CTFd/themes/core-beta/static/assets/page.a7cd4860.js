import{C as o,m as d}from"./index.69d1de7e.js";window.CTFd=o;window.Alpine=d;d.start();
